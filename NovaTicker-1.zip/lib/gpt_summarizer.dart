Future<String> summarizeWithGpt(String news) async {
  // 실제 GPT 호출이 들어갈 자리 (예시는 단순 요약)
  await Future.delayed(const Duration(seconds: 1));
  return "삼성전자 AI 반도체, FDA 승인 등으로 급등 뉴스 발생.";
}