import 'package:flutter/material.dart';
import 'news_fetcher.dart';
import 'gpt_summarizer.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? _summary;
  bool _loading = false;

  Future<void> _fetchAndSummarize() async {
    setState(() {
      _loading = true;
    });

    final news = await fetchLatestNews();
    final summary = await summarizeWithGpt(news);

    setState(() {
      _summary = summary;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('급등주 호재 알림 앱')),
      body: Center(
        child: _loading
            ? const CircularProgressIndicator()
            : _summary != null
                ? Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(_summary!),
                  )
                : const Text('최신 뉴스를 요약하려면 버튼을 누르세요.'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _fetchAndSummarize,
        child: const Icon(Icons.refresh),
      ),
    );
  }
}