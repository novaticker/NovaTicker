Future<String> fetchLatestNews() async {
  // 실제 뉴스 크롤링/API 호출이 들어갈 자리 (예시는 하드코딩)
  await Future.delayed(const Duration(seconds: 1));
  return "삼성전자가 AI 반도체 신제품을 발표하면서 주가가 급등하고 있습니다. 미국 FDA가 한국 바이오 기업의 치료제를 승인하며 관련 종목이 급등했습니다.";
}